#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import pandas as pd

import matplotlib.pyplot as plt

import seaborn as sns

import plotly.graph_objects as go
from scipy.stats import multivariate_normal as mn

from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split


# In[4]:


diabetes = pd.read_csv(r'diabetes.csv')
print(f'diabetes.shape: {diabetes.shape}')


# In[5]:


diabetes.head()
diabetes.dtypes


# In[6]:


diabetes.describe()


# In[5]:


diabetes.info()


# In[6]:


#Finding the Missing and Zero Values
print(diabetes.isnull().any() .sum())
print(diabetes.isnull() .sum())


# In[7]:


#Drop all rows that contain missing values
diabetes = diabetes.dropna()
diabetes.shape


# In[8]:


#Get data where none of the columns has 0 value (except the first and last columns)
diabetes = diabetes[~(diabetes[diabetes.columns[1:-1]] == 0).any(axis=1)]
diabetes.shape


# In[9]:


get_ipython().run_cell_magic('HTML', '', '<style type="text/css">\ntable.dataframe td, table.dataframe th {\n    border: 1px black solid !important;\n}\n</style>')


# In[10]:


diabetes.describe()


# In[11]:


#Check the mean of values depending on their category (i.e. 0 or 1)
diabetes.groupby('Diabetic').mean()


# In[12]:


diabetes.groupby('Diabetic').agg(['mean', 'median'])


# In[13]:


for i,col in enumerate(diabetes.columns[:-1]):
    plt.figure(i)
    sns.displot(diabetes[col]);


# In[14]:


sns.pairplot(diabetes, hue="Diabetic", diag_kind='hist');


# In[15]:


diabetes.corr()


# In[16]:


plt.figure(figsize=(9,9))
sns.heatmap(np.abs(diabetes.corr()), annot=True, cmap="viridis", fmt="0.2f");


# In[17]:


diabetes.cov()


# In[18]:


plt.figure(figsize=(9,9))
sns.heatmap(np.abs(diabetes.cov()), annot=True, cmap="viridis", fmt="0.2f");


# In[19]:


sns.boxplot(x="Diabetic", y="BMI", data=diabetes, whis=3.0);


# In[20]:


plt.figure(figsize=(10,9))
plt.hist2d(diabetes["PlasmaGlucose"], diabetes["BMI"], bins=(20,20), cmap="magma")
plt.xlabel("PlasmaGlucose")
plt.ylabel("BMI")
plt.colorbar();


# In[21]:


plt.figure(figsize=(9,9))

m = diabetes["Diabetic"] == 1
plt.scatter(diabetes.loc[m, "PlasmaGlucose"], diabetes.loc[m, "BMI"], c="r", s=15, label="Diabetic")
plt.scatter(diabetes.loc[~m, "PlasmaGlucose"], diabetes.loc[~m, "BMI"], c="b", s=15, label="Diabetic")
plt.xlabel("PlasmaGlucose")
plt.ylabel("BMI")
plt.legend(loc=2);


# In[22]:


#Age, Blood Pressure Bar Chart
#Age, Blood Pressure, and Pregnancies Scatter Plot/ Line Chart
#Drop Patient ID and Tricep Thickness


# In[23]:


diabetes.head()


# In[31]:


x, y = diabetes.values[:, :-1], diabetes.values[:, -1]


# In[62]:


x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.01, random_state=42, stratify=y)


# In[63]:


from sklearn.preprocessing import StandardScaler


# In[64]:


model = LogisticRegression()
model.fit(x_train, y_train)


# In[65]:


accuracy = model.score(x_test, y_test)
print("accuracy = ", accuracy * 100, '%')


# In[66]:


#coeff = list(model.coef_[0])
#labels = diabetes.columns[:-1]
#features = pd.DataFrame()


# In[67]:


from sklearn.naive_bayes import GaussianNB
nb = GaussianNB()
nb.fit(x_train, y_train)


# In[68]:


accuracy = model.score(x_test, y_test)
print("accuracy = ", accuracy * 100, '%')


# In[ ]:




