#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


data = pd.read_csv(r'diabetes.csv')


# In[3]:


data.head()


# In[4]:


data.tail()


# In[5]:


print("No. of Rows", data.shape[0])
print("No. of Columns", data.shape[1])


# In[6]:


data.info()


# In[7]:


data.isnull().sum()


# In[8]:


data.describe()


# In[9]:


import numpy as np


# In[10]:


data_copy = data.copy(deep=True)


# In[11]:


data.columns


# In[12]:


data_copy[['Pregnancies']].replace(0,np.nan)


# In[13]:


data_copy.isnull().sum()


# In[14]:


x=data.drop('Diabetic', axis=1)
y=data['Diabetic']


# In[15]:


x


# In[16]:


y


# In[17]:


from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.20, random_state=42, stratify=y)


# In[18]:


from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC

from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import GradientBoostingClassifier

from sklearn.pipeline import Pipeline


# In[19]:


pipeline_lr = Pipeline([('scalar1', StandardScaler()),
                       ('lr_classifier', LogisticRegression())])

pipeline_knn = Pipeline([('scalar2', StandardScaler()),
                       ('knn_classifier', KNeighborsClassifier())])

pipeline_svc = Pipeline([('scalar3', StandardScaler()),
                       ('svc_classifier', SVC())])

pipeline_dt = Pipeline([('dt_classifier', DecisionTreeClassifier())])
pipeline_rf = Pipeline([('rf_classifier', RandomForestClassifier())])
pipeline_gbc = Pipeline([('gbc_classifier', GradientBoostingClassifier())])


# In[20]:


pipelines = [pipeline_lr,
            pipeline_knn,
            pipeline_svc,
            pipeline_dt,
            pipeline_rf,
            pipeline_gbc]


# In[21]:


pipelines


# In[22]:


for pipe in pipelines:
    pipe.fit(x_train, y_train)


# In[23]:


pipe_dict = {0: 'LR',
            1: 'KNN',
            2: 'SVC',
            3: 'DT',
            4: 'RF',
            5: 'GBC'}


# In[24]:


pipe_dict


# In[25]:


for i, model in enumerate(pipelines):
    print("{} Test Accuracy:{}" .format(pipe_dict[i], model.score(x_test, y_test)))


# In[26]:


from sklearn.ensemble import GradientBoostingClassifier


# In[27]:


x=data.drop('Diabetic', axis=1)
y=data['Diabetic']


# In[28]:


gbc = GradientBoostingClassifier(max_depth=3)


# In[29]:


gbc.fit(x,y)


# In[30]:


new_data = pd.DataFrame({
    'PatientID': 1201647,
    'Pregnancies': 8, 
    'PlasmaGlucose': 80,
    'DiastolicBloodPressure': 95,
    'TricepsThickness': 33,
    'SerumInsulin': 24, 
    'BMI': 26.62492885, 
    'Diabetes Pedigree': 0.443947388, 
    'Age': 53,
}, index = [0])


# In[31]:


gbc.predict(new_data)


# In[32]:


y_predict = gbc.predict(x_test)
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_predict)


# In[33]:


score = gbc.score(x_test, y_test)


# In[34]:


cm


# In[35]:


score


# In[36]:


def calculate_precision(true_positives, false_positives):
    """Calculates the precision given the number of true positives and false positives."""
    return true_positives / (true_positives + false_positives)

# Example usage:
true_positives = 70
false_positives = 20

precision = calculate_precision(true_positives, false_positives)
print("Precision:", precision)


# In[ ]:




